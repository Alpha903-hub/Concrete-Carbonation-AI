# Data directory

- `source/` contains the supplied RILEM article and supplementary workbook.
- `processed/` contains project-prepared datasets and data-audit workbooks.
- `evaluation/` contains supplied prediction-level and study-level evaluation artifacts.

Keep the original source immutable. Consult `../docs/data/RECONSTRUCTION_PLAN.md` before modifying processed data. Verify source and supplementary-material licensing before redistributing the repository publicly.
