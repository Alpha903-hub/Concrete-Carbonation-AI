from pathlib import Path
import json
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "data/evaluation/predictions_groupkfold.csv"
df = pd.read_csv(source)

required = {"fold", "source_reference", "valeur_reelle", "prediction_baseline", "prediction_rf"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing columns: {sorted(missing)}")

# Check that each source study belongs to exactly one fold.
folds_per_study = df.groupby("source_reference")["fold"].nunique()
if (folds_per_study > 1).any():
    raise ValueError("Study leakage detected: at least one source_reference occurs in multiple folds.")

def metrics(y, p):
    return {
        "n": int(len(y)),
        "MAE": float(mean_absolute_error(y, p)),
        "RMSE": float(mean_squared_error(y, p) ** 0.5),
        "R2": float(r2_score(y, p)),
        "bias_prediction_minus_observed": float((p - y).mean()),
    }

result = {
    "n_observations": int(len(df)),
    "n_studies": int(df["source_reference"].nunique()),
    "fold_sizes": {str(k): int(v) for k, v in df["fold"].value_counts().sort_index().items()},
    "baseline": metrics(df["valeur_reelle"], df["prediction_baseline"]),
    "random_forest": metrics(df["valeur_reelle"], df["prediction_rf"]),
}
result["mae_reduction_percent"] = (
    1 - result["random_forest"]["MAE"] / result["baseline"]["MAE"]
) * 100

fel = df[df["source_reference"].astype(str).str.lower() == "fel15"]
if not fel.empty:
    result["FEL15"] = metrics(fel["valeur_reelle"], fel["prediction_rf"])

out = ROOT / "data/evaluation/recomputed_metrics.json"
out.write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
