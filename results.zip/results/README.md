# Results

`graphiques_carbonatation.pdf` is the graphical results document supplied by the project author. Numeric evaluation artifacts are stored in `data/evaluation/`.

All plots and metrics should be regenerated from versioned code before a formal scientific publication.
