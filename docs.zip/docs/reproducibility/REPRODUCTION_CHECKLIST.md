# Reproduction checklist

- [ ] Confirm Python and package versions.
- [ ] Record source files and SHA-256 hashes.
- [ ] Confirm the row-level observational unit.
- [ ] Reconstruct raw-to-processed transformations.
- [ ] Run data-integrity tests.
- [ ] Recreate group folds and verify no study overlap.
- [ ] Fit preprocessing within each training fold.
- [ ] Reproduce baseline and Random Forest metrics.
- [ ] Reproduce FEL15 and study-level analysis.
- [ ] Evaluate extraction against manually annotated held-out paragraphs.
- [ ] Record hardware, Qwen revision, quantization and inference settings.
- [ ] Archive final configuration and outputs.
