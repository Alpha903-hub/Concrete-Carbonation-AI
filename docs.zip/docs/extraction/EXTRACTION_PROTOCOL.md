# Scientific text extraction protocol | Protocole d'extraction

Qwen3-8B is intended to identify experimental variables explicitly stated in scientific paragraphs. It must not infer unreported values or predict the measured carbonation depth.

Rules:
- Unknown/unreported values remain `null`.
- Zero is allowed only when explicit source wording supports zero/absence.
- Each extracted field should include a literal evidence excerpt.
- Preserve source quantity and unit in the evidence record.
- Convert units in deterministic Python code.
- Normalize controlled categories in deterministic code.
- Keep target measurements separate from predictor extraction.
- Retain document, page, paragraph, and study identifiers.

Evaluation required: manually annotate paragraphs from studies excluded from model training. Report per-field exact match or numerical tolerance, unit-conversion accuracy, evidence-span validity, false-positive extraction rate, and missing-field precision/recall. One successful example is an integration smoke test, not scientific validation.
