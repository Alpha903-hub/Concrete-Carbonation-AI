# Scientific documentation plan | Plan documentaire scientifique

These are substantive technical chapters to write and cite, not short summaries. Each chapter must define terms, explain mechanisms, state assumptions and exceptions, connect concepts to dataset fields, and cite primary literature with page/section references. Publish in English and French.

1. **Carbonation mechanisms** — CO₂ transport, dissolution, aqueous chemistry, alkaline buffering, carbonation front; natural versus accelerated exposure.
2. **Cement chemistry and carbonatable phases** — portlandite, C-S-H decalcification, clinker phases, SCMs, calcium availability, alkalis; limits of simplified reaction equations.
3. **Transport and moisture** — gas diffusion, effective diffusivity, pore saturation, moisture dependence, and non-monotonic effects of relative humidity.
4. **Material and exposure variables** — water/binder ratio, binder content, clinker fraction, SCM type/content, curing, preconditioning, temperature, RH, CO₂ concentration and exposure time; map to available fields and identify absent parameters.
5. **Empirical and mechanistic models** — square-root-of-time relationships, assumptions, empirical fit versus mechanistic model versus ML regression.
6. **Measurement and experimental comparability** — carbonation-depth methods, indicator methods, specimen geometry, exposure regimes, curing, replicates, cross-study comparability.
7. **ML for scientific tabular data** — leakage, grouped splits, fold-local preprocessing, baselines, MAE, RMSE, R², bias, uncertainty and domain shift.

Every chapter: definitions; equations and units; assumptions; exceptions; dataset mapping; implications for model validity; references.
