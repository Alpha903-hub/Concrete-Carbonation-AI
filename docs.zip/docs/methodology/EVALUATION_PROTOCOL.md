# Evaluation protocol | Protocole d'évaluation

Supplied record: five-fold GroupKFold grouped by `source_reference`, 9,359 out-of-fold rows and 88 studies.

Reported metrics:
- Baseline MAE: 3.3756 mm
- Random Forest MAE: 2.1198 mm
- Baseline RMSE: 5.1540 mm
- Random Forest RMSE: 3.9012 mm
- Baseline R²: -0.0909
- Random Forest R²: 0.3750
- Reported MAE reduction: 37.20%

FEL15: n=1,021; MAE=5.4642 mm; RMSE=7.3447 mm; R²=-7.7135; bias (prediction minus observed)=+5.3699 mm.

Before claiming independent reproducibility:
1. Re-run fold generation and verify each source appears in one test fold only.
2. Verify imputation, encoding, scaling and feature selection are fitted only on training data within each fold.
3. Define baseline mathematically and rule out test-target leakage.
4. Record hyperparameters, seeds, library versions and feature order.
5. Recompute metrics from prediction-level output.
6. Confirm bias convention.
7. Publish per-study metrics and residual plots.
8. Keep all-study results primary; label exclusions as sensitivity analysis.

Positive bias means overprediction under the stated convention. Negative R² indicates worse performance than the evaluation-set mean predictor under the standard definition. Pooled MAE gain does not prove transferability to every experimental domain.
