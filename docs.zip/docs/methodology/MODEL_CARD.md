# Model card | Fiche du modèle

**Model:** Random Forest regression for `carbonation_depth_mm`.  
**Intended use:** research into data-driven estimation from experimental variables in the supplied carbonation dataset.  
**Not intended for:** structural design, safety decisions, regulatory compliance, service-life certification, or replacement of experimental testing.

Current supplied evaluation: five-fold GroupKFold grouped by `source_reference`; pooled OOF MAE 2.1198 mm, RMSE 3.9012 mm, R² 0.3750. FEL15 MAE 5.4642 mm and R² -7.7135.

Known limitations: severe study-specific failure on FEL15; possible protocol/domain differences; incomplete raw-to-processed history; exact hyperparameters and baseline require verification; no calibrated predictive uncertainty documented; extraction not fully evaluated on manually annotated held-out paragraphs.

Before release, record exact features, preprocessing, hyperparameters, seed, data version/hash, fold assignments, package versions, and model artifact hash.
