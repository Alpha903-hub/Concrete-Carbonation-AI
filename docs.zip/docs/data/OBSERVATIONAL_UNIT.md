# Observational unit | Unité d'observation

The supplied processed CSV `carbonation_cleaned_for_eda.csv` contains 9,359 rows and 72 columns, with 88 distinct `source_reference` values. The related `carbonation_longitudinal.csv` contains 9,359 rows and 56 columns.

The RILEM supplementary workbook's `gerneral information` sheet has 1,748 spreadsheet rows and 207 columns, including multi-row headers and metadata rows. It must not be treated as a flat table without interpreting its header structure.

The exact meaning of one row in each processed file is not conclusively established by filename or row count alone. Determine whether rows represent a particular carbonation measurement at a particular exposure time, a mix-level record, or a repeated measurement.

Required audit:
1. Identify actual header rows and data-start row in each source sheet.
2. Identify stable keys (database number, source reference, mix number, exposure condition, time, replicate).
3. Determine whether a mix has multiple exposure times or environments.
4. Compare keys/cardinalities between source sheets and processed files.
5. Verify repeated measurements and their representation.
6. Publish a concrete example and a key-uniqueness test.

Do not call the 9,359 rows “9,359 mixes” unless the audit proves it.
