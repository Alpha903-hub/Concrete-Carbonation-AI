# Raw-to-processed reconstruction plan | Plan de reconstruction

## Supplied inputs
- `data/source/RILEM_TC281_CCC_supplementary_workbook.xlsx`
- `data/processed/carbonation_cleaned_for_eda.csv`
- `data/processed/carbonation_longitudinal.csv`
- `data/processed/carbonation_dataset_restructured.xlsx`
- `data/processed/carbonation_quality_review.xlsx`
- `data/processed/carbonation_repeated_measurements_review.xlsx`
- `data/processed/carbonation_exposure_comparison.xlsx`
- `data/processed/carbonation_eda_results.xlsx`

## Objective
Reconstruct, rather than guess, how the original RILEM supplementary workbook relates to the processed tables.

## Required outputs
1. `source_sheet_inventory.csv`: sheet names, dimensions, header rows, data rows.
2. `variable_mapping.csv`: source sheet/column, processed field, unit, conversion, rationale, status.
3. `transformation_log.csv`: ordered operation, input/output, code reference, row counts, rationale.
4. `key_integrity_report.csv`: duplicate keys, repeated measurements, unmatched records.
5. `missingness_comparison.csv`: missing count and percentage before/after.
6. `dataset_comparison.ipynb`: executable comparison and diagnostics.
7. Confirmed definition of the observational unit.

## Protocol
- Preserve the original workbook unchanged.
- Parse multi-row headers explicitly.
- Establish stable keys before joining.
- Compare source and processed values with unit-appropriate tolerances.
- Report unmatched rows and fields.
- Do not infer why a row was excluded; locate the code or document an author question.
- Distinguish cleaning, feature engineering, and modeling-specific filtering.

## Status
Pending reconstruction. The supplied notebook begins its audit from `carbonation_cleaned_for_eda.csv`; it does not by itself prove the complete raw-workbook-to-CSV transformation chain.
