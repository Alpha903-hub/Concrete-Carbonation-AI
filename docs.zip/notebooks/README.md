# Notebook notes

`00_project_working_notebook.ipynb` is based on the notebook supplied by the author. Cell outputs and execution counters were removed. The optional ipywidgets interface cell was omitted; the core research workflow remains represented.

The notebook is stateful and was developed in Google Colab. It must be run from a fresh runtime, top to bottom, and refactored before being advertised as a robust reproducibility pipeline. Some cells rely on variables created earlier. Review the model configuration and data paths before rerunning.
