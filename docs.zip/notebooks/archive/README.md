# Original notebook snapshot

`original_colab_notebook_as_received.ipynb` is the exact notebook file supplied by the author. It is preserved for provenance and comparison, not as the recommended public entry point. It retains cell outputs, execution state, and an optional interactive ipywidgets interface cell. Use `../00_project_working_notebook.ipynb` as the cleaned research copy. The original snapshot was scanned for common API-token patterns; no obvious credential pattern was detected, but the author should still review it before making the repository public.
