import pandas as pd

TARGET = "carbonation_depth_mm"
GROUP = "source_reference"

def validate_required_columns(df: pd.DataFrame) -> None:
    required = {TARGET, GROUP}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
