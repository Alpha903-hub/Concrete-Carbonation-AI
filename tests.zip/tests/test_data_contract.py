import pandas as pd
import pytest
from src.data_contract import validate_required_columns

def test_required_columns_pass():
    validate_required_columns(pd.DataFrame({
        "carbonation_depth_mm": [1.2],
        "source_reference": ["study_a"],
    }))

def test_required_columns_fail():
    with pytest.raises(ValueError):
        validate_required_columns(pd.DataFrame({"carbonation_depth_mm": [1.2]}))
